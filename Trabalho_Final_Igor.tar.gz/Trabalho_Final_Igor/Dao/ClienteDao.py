from database import db
from Model import Cliente
#Atributos: id,nome,data_nascimento,nacionalidade,
# contato,senha_hash,data_login,data_saida
class ClienteDAO:
    @staticmethod
    def get_Cliente(id):
        return Cliente.query.get(id)

    @staticmethod
    def get_all_Cliente():
        return Cliente.query.all()

    @staticmethod
    def add_Cliente(nome,data_nascimento,nacionalidade,contato,senha_hash,data_login,data_saida):
        cliente = Cliente(nome=nome,data_nascimento=data_nascimento,nacionalidade=nacionalidade,contato=contato,senha_hash=senha_hash,data_login=data_login,data_saida=data_saida)
        if cliente:
            db.session.add(cliente)
            db.session.commit()
        return cliente

    @staticmethod
    def att_Cliente(id,nome,data_nascimento,nacionalidade,contato,senha_hash,data_login,data_saida):
        cliente = Cliente.query.get(id)
        if cliente:
 
            cliente.nome = nome
            cliente.data_nascimento = data_nascimento
            cliente.nacionalidade = nacionalidade
            cliente.contato=contato
            cliente.senha_hash=senha_hash
            cliente.data_login=data_login
            cliente.data_saida=data_saida

            db.session.commit()  
        return cliente

    @staticmethod
    def del_Cliente(id):
        cliente = ClienteDAO.get_Cliente(id)
        if cliente:
            db.session.delete(cliente)
            db.session.commit()
        return cliente
    
    @staticmethod
    def cliente_to_json(cliente):
        return {
            "id": cliente.id,
            "nome": cliente.nome,
            "data_nascimento": cliente.data_nascimento.isoformat() ,
            "nacionalidade": cliente.nacionalidade,
            "contato": cliente.contato,
            "senha_hash": cliente.senha_hash,
            "data_login":cliente.data_login.isoformat() ,
            "data_saida":cliente.data_saida.isoformat() if cliente.data_saida else None
        }
    @staticmethod
    def clientes_to_json(clientes):
        return [ClienteDAO.cliente_to_json(cliente) for cliente in clientes]
    
    def cliente_to_json_admin(cliente):
        return {
            # arrumar isso para ser os ids para que o admin veja
            "id": cliente.id,
            "nome": cliente.nome,
            "data_nascimento": cliente.data_nascimento.isoformat() ,
            "nacionalidade": cliente.nacionalidade,
            "contato": cliente.contato,
            "senha_hash": cliente.senha_hash,
            "data_login":cliente.data_login.isoformat() ,
            "data_saida":cliente.data_saida.isoformat() if cliente.data_saida else None
        }
    @staticmethod
    def clientes_to_json_admin(clientes):
        return [ClienteDAO.cliente_to_json_admin(cliente) for cliente in clientes]