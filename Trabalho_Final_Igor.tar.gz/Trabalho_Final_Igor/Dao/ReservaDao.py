from database import db
from Model import Reserva

class ReservaDAO:

    @staticmethod
    def get_Reserva_por_id(id):
        return Reserva.query.get(id)
    
    @staticmethod
    def get_Reserva_por_status(status):
        return Reserva.query.get(status)
    
    @staticmethod
    def get_all_Reserva():
        return Reserva.query.all()
    
    
    @staticmethod
    def add_Reserva(preco,data_checkin,data_checkout,servico,id_cliente,id_reserva,tipo_reserva,id_funcionario,status):
        reserva = Reserva(preco=preco,data_checkin=data_checkin,data_checkout=data_checkout,servico=servico,id_cliente=id_cliente,id_reserva=id_reserva,tipo_reserva=tipo_reserva,id_funcionario=id_funcionario,status=status)
        if reserva:
            db.session.add(reserva)
            db.session.commit()
        return reserva

    @staticmethod
    def att_Reserva(id,preco,data_checkin,data_checkout,servico,id_cliente,id_reserva,tipo_reserva,id_funcionario,status):
        reserva = Reserva.query.get(id)
        if reserva:
 
            reserva.preco = preco
            reserva.data_checkin = data_checkin
            reserva.data_checkout = data_checkout
            reserva.servico = servico
            reserva.id_cliente = id_cliente
            reserva.id_reserva = id_reserva   
            reserva.tipo_reserva = tipo_reserva
            reserva.id_funcionario = id_funcionario
            reserva.status = status

            db.session.commit()

        return reserva

    @staticmethod
    def del_Reserva(id):
        reserva = ReservaDAO.get_Reserva_por_id(id)
        if reserva:
            db.session.delete(reserva)
            db.session.commit()
        return reserva
    
    @staticmethod
    def reserva_to_json(reserva):
        return {
            "id":reserva.id,
            "preco":reserva.preco,
            "checkin":reserva.data_checkin, #pq vc colocou checkin inves de data_checkin, acho melhor trocar pq gera inconscistência
            "checkout":reserva.data_checout,
            "tipo":reserva.tipo.descricao,   #esse tipo tem que ser transformado pra string pq aqui é o id tipo
            "capacidade":reserva.quarto.capacidade
        }
    
    @staticmethod
    def reserva_to_json_admin(reserva):
        return {
            "id":reserva.id,
            "preco":reserva.preco,
            "checkin":reserva.data_checkin,
            "checkout":reserva.data_checkout,
            "tipo":reserva.tipo.descricao,
            "capacidade":reserva.quarto.capacidade
        }
    
    @staticmethod
    def reservas_to_json(reservas):
        return [ReservaDAO.reserva_to_json(reserva) for reserva in reservas]