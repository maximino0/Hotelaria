from database import db
from Model import Quarto
#Atributos: id,tipo,preco,capacidade
class QuartoDAO:
    @staticmethod
    def get_Quarto(id):
        return Quarto.query.get(id)

    @staticmethod
    def get_all_Quarto():
        return Quarto.query.all()

    @staticmethod
    def add_Quarto(tipo,capacidade):
        #transformar tipo em id_tipo
        quarto = Quarto(tipo=tipo,capacidade=capacidade)
        if quarto:
            db.session.add(quarto)
            db.session.commit()
        return quarto

    @staticmethod
    def att_Quarto(id,tipo,capacidade):
        quarto = Quarto.query.get(id)
        if quarto:
 
            quarto.tipo=tipo
            quarto.capacidade=capacidade

            db.session.commit()  
        return quarto

    @staticmethod
    def del_Quarto(id):
        quarto = QuartoDAO.get_Quarto(id)
        if quarto:
            db.session.delete(quarto)
            db.session.commit()
        return quarto
    @staticmethod
    def Quarto_to_json(quarto):
        return {
            "id":quarto.id,
            "tipo":quarto.tipo,   #tem que pegar o tipo e o preço da tabela tipo
            "preco":quarto.preco,
            "capacidade":quarto.capacidade

        }
    def Quarto_to_json_admin(quarto):
        return {
            "id":quarto.id,
            "tipo":quarto.tipo,   #esse tipo é o id
            "capacidade":quarto.capacidade

        }
    @staticmethod
    def Quartos_to_json(quartos):
        return [QuartoDAO.Quarto_to_json(quarto) for quarto in quartos]
    
    @staticmethod
    def Quartos_to_json_admin(quartos):
        return [QuartoDAO.Quarto_to_json_admin(quarto) for quarto in quartos]