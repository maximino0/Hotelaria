from database import db
from Model import Comanda

#Atributos: id,preco_estadias,preco_frigobar,preco_servicos

class ComandaDAO:
    @staticmethod
    def get_Comanda(id):
        return Comanda.query.get(id)

    @staticmethod
    def get_all_Comanda():
        return Comanda.query.all()

    @staticmethod
    def add_Comanda(preco_estadias,preco_frigobar,preco_servicos):
        comanda = Comanda(preco_estadias=preco_estadias,preco_frigobar=preco_frigobar,preco_servicos=preco_servicos)
        if comanda:
            db.session.add(comanda)
            db.session.commit()
        return comanda

    @staticmethod
    def att_Comanda(id,preco_estadias,preco_frigobar,preco_servicos):
        comanda = Comanda.query.get(id)
        if comanda:
 
            comanda.preco_estadias=preco_estadias
            comanda.preco_frigobar=preco_frigobar
            comanda.preco_servicos=preco_servicos

            db.session.commit()  
        return comanda

    @staticmethod
    def del_Comanda(id):
        comanda = ComandaDAO.get_Comanda(id)
        if comanda:
            db.session.delete(comanda)
            db.session.commit()
        return comanda
    @staticmethod
    def Comanda_to_json(comanda):
        return {
            "id": comanda.id,
            "preco_estadias":comanda.preco_estadias,
            "preco_frigobar":comanda.preco_frigobar,
            "preco_servicos":comanda.preco_servicos
        }
    @staticmethod
    def Comanda_to_json_admin(comanda):
        return {
            "id": comanda.id,
            "preco_estadias":comanda.preco_estadias,
            "preco_frigobar":comanda.preco_frigobar,
            "preco_servicos":comanda.preco_servicos
        }
    @staticmethod
    def Comandas_to_json(comandas):
        return [ComandaDAO.Comanda_to_json(comanda) for comanda in comandas]
    @staticmethod
    def Comandas_to_json_admin(comandas):
        return [ComandaDAO.Comanda_to_json_admin(comanda) for comanda in comandas]