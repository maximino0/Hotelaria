from database import db
from Model import Funcionario
#Atributos: id,nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em

class FuncionarioDAO:
    @staticmethod
    def get_Funcionario(id):
        return Funcionario.query.get(id)

    @staticmethod
    def get_all_Funcionario():
        return Funcionario.query.all()

    @staticmethod
    def add_Funcionario(nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em):
        funcionario = Funcionario(nome=nome,data_nascimento=data_nascimento,nacionalidade=nacionalidade,contato=contato,senha_hash=senha_hash,cargo=cargo,criado_em=criado_em)
        if funcionario:
            db.session.add(funcionario)
            db.session.commit()
        return funcionario

    @staticmethod
    def att_Funcionario(id,nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em):
        funcionario = Funcionario.query.get(id)
        if funcionario:
 
            funcionario.nome = nome
            funcionario.data_nascimento = data_nascimento
            funcionario.nacionalidade = nacionalidade
            funcionario.contato=contato
            funcionario.senha_hash=senha_hash
            funcionario.cargo=cargo
            funcionario.criado_em=criado_em

            db.session.commit()  
        return funcionario

    @staticmethod
    def del_Funcionario(id):
        funcionario = FuncionarioDAO.get_Funcionario(id)
        if funcionario:
            db.session.delete(funcionario)
            db.session.commit()
        return funcionario
    @staticmethod
    def Funcionario_to_json(funcionario):
        return {
            "id": funcionario.id,
            "nome": funcionario.nome,
            "data_nascimento": funcionario.data_nascimento.isoformat(),
            "nacionalidade": funcionario.nacionalidade,
            "contato": funcionario.contato,
            "senha_hash": funcionario.senha_hash,
            "cargo":funcionario.cargo,
            "criado_em":funcionario.criado_em.isoformat() 
        }
    @staticmethod
    def Funcionarios_to_json(funcionarios):
        return [FuncionarioDAO.Funcionario_to_json(funcionario) for funcionario in funcionarios]
    
    @staticmethod
    def Funcionario_to_json_admin(funcionario):
        return {
            "id": funcionario.id,
            "nome": funcionario.nome,
            "data_nascimento": funcionario.data_nascimento.isoformat(),
            "nacionalidade": funcionario.nacionalidade,
            "contato": funcionario.contato,
            "senha_hash": funcionario.senha_hash,
            "cargo":funcionario.cargo,
            "criado_em":funcionario.criado_em.isoformat() 
        }
    @staticmethod
    def Funcionarios_to_json_admin(funcionarios):
        return [FuncionarioDAO.Funcionario_to_json_admin(funcionario) for funcionario in funcionarios]