from Dao import ReservaDAO

class ReservaRepository:
    def __init__(self):
        self.ReservaDao = ReservaDAO()

    def get_all_Reservas(self):
        return self.ReservaDao.get_all_Reserva()

    def get_Reserva_by_id(self, Reserva_id):
        return self.ReservaDao.get_Reserva(Reserva_id)

    def create_Reserva(self,nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em):
        return self.ReservaDao.add_Reserva(nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em)
    
    def update_Reserva(self,nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em):
        return self.ReservaDao.att_Reserva(nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em)

    def delete_Reserva(self, Reserva_id):
        return self.ReservaDao.del_Reserva(Reserva_id)

    def Reserva_to_json(self, Reserva):
        return self.ReservaDao.Reserva_to_json(Reserva)

    def Reservas_to_json(self, Reservas):
        return self.ReservaDao.Reservas_to_json(Reservas)
    
    def Reserva_to_json_admin(self, Reserva):
        return self.ReservaDao.Reserva_to_json_admin(Reserva)

    def Reservas_to_json_admin(self, Reservas):
        return self.ReservaDao.Reservas_to_json_admin(Reservas)
