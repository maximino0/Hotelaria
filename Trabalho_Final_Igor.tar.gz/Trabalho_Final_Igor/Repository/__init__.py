from .ClienteRepository import *
from .ComandaRepository import *
from .FuncionarioRepository import *
from .QuartoRepository import *
from .ReservaRepository import *