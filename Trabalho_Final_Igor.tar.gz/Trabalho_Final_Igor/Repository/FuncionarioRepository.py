from Dao import FuncionarioDAO

class FuncionarioRepository:
    def __init__(self):
        self.FuncionarioDao = FuncionarioDAO()

    def get_all_Funcionarios(self):
        return self.FuncionarioDao.get_all_Funcionario()

    def get_Funcionario_by_id(self, Funcionario_id):
        return self.FuncionarioDao.get_Funcionario(Funcionario_id)

    def create_Funcionario(self,nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em):
        return self.FuncionarioDao.add_Funcionario(nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em)
    
    def update_Funcionario(self,nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em):
        return self.FuncionarioDao.att_Funcionario(nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em)

    def delete_Funcionario(self, Funcionario_id):
        return self.FuncionarioDao.del_Funcionario(Funcionario_id)

    def Funcionario_to_json(self, Funcionario):
        return self.FuncionarioDao.Funcionario_to_json(Funcionario)

    def Funcionarios_to_json(self, Funcionarios):
        return self.FuncionarioDao.Funcionarios_to_json(Funcionarios)
    
    def Funcionario_to_json_admin(self, Funcionario):
        return self.FuncionarioDao.Funcionario_to_json_admin(Funcionario)

    def Funcionarios_to_json_admin(self, Funcionarios):
        return self.FuncionarioDao.Funcionarios_to_json_admin(Funcionarios)
