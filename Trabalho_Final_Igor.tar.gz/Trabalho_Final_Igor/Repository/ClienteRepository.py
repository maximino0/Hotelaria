from Dao import ClienteDAO

class ClienteRepository:
    def __init__(self):
        self.clienteDao = ClienteDAO()

    def get_all_clientes(self):
        return self.clienteDao.get_all_Cliente()

    def get_cliente_by_id(self, cliente_id):
        return self.clienteDao.get_Cliente(cliente_id)

    def create_cliente(self, nome, data_nascimento, nacionalidade, contato, senha_hash, data_login, data_saida):
        return self.clienteDao.add_Cliente(nome, data_nascimento, nacionalidade, contato, senha_hash, data_login, data_saida)

    def update_cliente(self, cliente_id, nome, data_nascimento, nacionalidade, contato, senha_hash, data_login, data_saida):
        return self.clienteDao.att_Cliente(cliente_id, nome, data_nascimento, nacionalidade, contato, senha_hash, data_login, data_saida)

    def delete_cliente(self, cliente_id):
        return self.clienteDao.del_Cliente(cliente_id)

    def cliente_to_json(self, cliente):
        return self.clienteDao.cliente_to_json(cliente)

    def clientes_to_json(self, clientes):
        return self.clienteDao.clientes_to_json(clientes)
    
    def cliente_to_json(self, cliente):
        return self.clienteDao.cliente_to_json_admin(cliente)

    def clientes_to_json(self, clientes):
        return self.clienteDao.clientes_to_json_admin(clientes)
