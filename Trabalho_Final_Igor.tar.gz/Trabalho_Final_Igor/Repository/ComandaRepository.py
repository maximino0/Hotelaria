from Dao import ComandaDAO

class ComandaRepository:
    def __init__(self):
        self.ComandaDao = ComandaDAO()

    def get_all_Comandas(self):
        return self.ComandaDao.get_all_Comanda()

    def get_Comanda_by_id(self, Comanda_id):
        return self.ComandaDao.get_Comanda(Comanda_id)

    def create_Comanda(self, preco_estadias,preco_frigobar,preco_servicos):
        return self.ComandaDao.add_Comanda(preco_estadias,preco_frigobar,preco_servicos)

    def update_Comanda(self, preco_estadias,preco_frigobar,preco_servicos):
        return self.ComandaDao.att_Comanda(preco_estadias,preco_frigobar,preco_servicos)

    def delete_Comanda(self, Comanda_id):
        return self.ComandaDao.del_Comanda(Comanda_id)

    def Comanda_to_json(self, Comanda):
        return self.ComandaDao.Comanda_to_json(Comanda)

    def Comandas_to_json(self, Comandas):
        return self.ComandaDao.Comandas_to_json(Comandas)
    
    def Comanda_to_json_admin(self, Comanda):
        return self.ComandaDao.Comanda_to_json_admin(Comanda)

    def Comandas_to_json_admin(self, Comandas):
        return self.ComandaDao.Comandas_to_json_admin(Comandas)
