from Dao import QuartoDAO

class QuartoRepository:
    def __init__(self):
        self.QuartoDao = QuartoDAO()

    def get_all_Quartos(self):
        return self.QuartoDao.get_all_Quarto()

    def get_Quarto_by_id(self, Quarto_id):
        return self.QuartoDao.get_Quarto(Quarto_id)

    def create_Quarto(self,tipo,capacidade):
        return self.QuartoDao.add_Quarto(tipo,capacidade)
    
    def update_Quarto(self,tipo,capacidade):
        return self.QuartoDao.att_Quarto(tipo,capacidade)

    def delete_Quarto(self, Quarto_id):
        return self.QuartoDao.del_Quarto(Quarto_id)

    def Quarto_to_json(self, Quarto):
        return self.QuartoDao.Quarto_to_json(Quarto)

    def Quartos_to_json(self, Quartos):
        return self.QuartoDao.Quartos_to_json(Quartos)
    
    def Quarto_to_json_admin(self, Quarto):
        return self.QuartoDao.Quarto_to_json_admin(Quarto)

    def Quartos_to_json_admin(self, Quartos):
        return self.QuartoDao.Quartos_to_json_admin(Quartos)
