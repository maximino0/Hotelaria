from database import db
from sqlalchemy import Date, DateTime, func, Enum

#Atributos: id,nome,data_nascimento,nacionalidade,contato,senha_hash,cargo,criado_em

class Funcionario(db.Model):
    __tablename__ = 'funcionario'

    id = db.Column(db.Integer,primary_key = True)
    nome= db.Column(db.String(80),nullable = False)
    data_nascimento = db.Column(db.Date, nullable = False)
    nacionalidade = db.Column(db.String(120), nullable = False)
    contato = db.Column(db.String(20), nullable = False)
    senha_hash = db.Column(db.String(128), nullable = False)
    cargo = db.Column(db.String(128), nullable = False)
    criado_em = db.Column(db.DateTime, default=func.now())
    # id_criador=
    
    reserva=db.relationship("Reserva",back_populates="funcionario")