from database import db
from sqlalchemy import Date, DateTime, func, Enum
#Atributos: id,tipo,preco,capacidade
from database import db
from sqlalchemy import Date, DateTime, func, Enum
#Atributos: id,tipo,preco,capacidade
class Tipo(db.Model):
    __tablename__ = 'tipo'

    id = db.Column(db.Integer,primary_key = True)
    descricao = db.Column(db.String(64), nullable = False)
    preco = db.Column(db.Float, nullable = False)

    reserva=db.relationship("Reserva",back_populates="tipo")#relacionamento com reserva
    quarto=db.relationship("Quarto",back_populates="tipo")#relacionamento com quarto
    
    
class Quarto(db.Model):
    __tablename__ = 'quarto'

    id = db.Column(db.Integer,primary_key = True)
    id_tipo=db.Column(db.Integer,db.ForeignKey('tipo.id')) #chave estrangeira de tipo
    capacidade = db.Column(db.Integer, nullable = False)
    status = db.Column(db.Boolean,default = True, nullable = False)

    reserva= db.relationship("Reserva",back_populates="quarto")#relacionamento com reserva
    tipo=db.relationship("Tipo",back_populates="quarto")#relacionamento com tipo
    
    