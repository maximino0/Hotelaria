from database import db
from sqlalchemy import Date, DateTime, func, Enum

class Quarto(db.Model):
    __tablename__ = 'quarto'

    id = db.Column(db.Integer,primary_key = True)
    tipo = db.Column(db.String(64), nullable = False)
    preco = db.Column(db.float, nullable = False)
    capacidade = db.Column(db.Integer, nullable = False)

    reserva= db.relationship("Reserva",back_populates="id_quarto")
    reserva_tipo=db.relationship("Reserva",back_populates="tipo_quarto")

    historico= db.relationship("Historico",back_populates="id_quarto")
    historico_tipo=db.relationship("Historico",back_populates="tipo_quarto")
    
    