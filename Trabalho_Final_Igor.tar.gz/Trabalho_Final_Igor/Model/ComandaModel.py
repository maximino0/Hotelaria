from database import db
from sqlalchemy import Date, DateTime, func, Enum

#Atributos: id,preco_estadias,preco_frigobar,preco_servicos

class Comanda(db.Model):
    __tablename__ = 'comanda'

    id = db.Column(db.Integer,primary_key = True)
    preco_estadias = db.Column(db.Float,nullable = False)
    preco_frigobar = db.Column(db.Float,nullable = True)
    preco_servicos = db.Column(db.Float,nullable = False)