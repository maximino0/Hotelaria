from database import db
from sqlalchemy import Date, DateTime, func, Enum


class Cliente(db.Model):
    __tablename__ = 'cliente'

    id = db.Column(db.Integer,primary_key = True)
    nome= db.Column(db.String(80),nullable = False)
    data_nascimento = db.Column(db.Date, nullable = False)
    nacionalidade = db.Column(db.String(120), nullable = False)
    contato = db.Column(db.String(120), nullable = False)
    senha_hash = db.Column(db.String(128), nullable = False)
    data_login = db.Column(db.DateTime, default=func.now(), nullable=False)
    data_saida = db.Column(db.DateTime, nullable=True)
    
    reserva=db.relationship("Reserva",back_populates="cliente")

        