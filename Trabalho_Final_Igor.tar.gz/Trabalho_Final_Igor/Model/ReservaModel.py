from database import db
from sqlalchemy import Date, DateTime, func, Enum
#Atributos: id,preco,data_checkin,data_checkout,servico,id_cliente,id_quarto,tipo_quarto,id_funcionario,status
class Reserva(db.Model):
    __tablename__ = 'reserva'

    id = db.Column(db.Integer,primary_key = True)
    preco = db.Column(db.Float, nullable = False)
    data_checkin = db.Column(db.DateTime, default=func.now(), nullable=False)
    data_checkout = db.Column(db.DateTime, nullable=False)
    servico = db.Column(db.String(80),nullable = False)
    id_cliente=db.Column(db.Integer,db.ForeignKey('cliente.id'))#chave estrangeira de cliente
    id_quarto=db.Column(db.Integer,db.ForeignKey('quarto.id'))#chave estrangeira de quarto
    id_tipo=db.Column(db.Integer,db.ForeignKey('tipo.id'))#chave estrangeira de tipo
    id_funcionario=db.Column(db.Integer, db.ForeignKey('funcionario.id'), nullable=True)#chave estrangeira de funcionario
    status = db.Column(db.Boolean,default = True, nullable = False)

    quarto= db.relationship("Quarto",back_populates="reserva") #relacionamento com quarto
    cliente=db.relationship("Cliente",back_populates="reserva")#relacionamento com cliente
    funcionario=db.relationship("Funcionario",back_populates="reserva")#relacionamento com funcionario
    tipo=db.relationship("Tipo",back_populates="reserva")#relacionamento com tipo
    #estavamos sendo cabaços pq simplesmnete vc nao precisa de duas ligações com a outra tabela, não é? vc so precisa ligar uma vez.