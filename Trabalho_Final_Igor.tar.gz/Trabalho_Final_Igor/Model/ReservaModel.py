from database import db
from sqlalchemy import Date, DateTime, func, Enum

class Reserva(db.Model):
    __tablename__ = 'reserva'

    id = db.Column(db.Integer,primary_key = True)
    preco = db.Column(db.float, nullable = False)
    data_checkin = db.Column(db.DateTime, default=func.now(), nullable=False)
    data_checkout = db.Column(db.DateTime, nullable=False)
    servico = db.Column(db.String(80),nullable = False)
    
    status = db.Column(db.Boolean,default = True, nullable = False)

    id_quarto= db.relationship("Quarto",back_populates="reserva")
    tipo_quarto=db.relationship("Quarto",back_populates="reserva")
    id_cliente=db.relationship("Cliente",back_populates="reserva")
    id_funcionario=db.relationship("Funcionario",back_populates="reserva")
