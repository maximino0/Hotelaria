from flask import Flask 
from database import init_db
from Controller import hotelController
from datetime import timedelta

app = Flask(__name__)
app.register_blueprint(hotelController)
app.secret_key = "sua-chave-secreta"
app.config['SESSION_COOKIE_SECURE'] = True
app.config['PERMANENT_SESSION_LIFETIME']=timedelta(days=7)

if __name__=='__main__':
    init_db(app)
    app.run(debug = True)