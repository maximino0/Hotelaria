from .ClienteController import *
from .ComandaController import *
from .FuncionarioController import *
from .QuartoController import *
from .ReservaController import *