from flask import Blueprint,redirect,url_for,render_template,request

