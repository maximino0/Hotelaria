from flask import redirect,url_for,render_template,request,flash,session
from Controller.BlueprintController import hotelController
from Funcao import *
from Repository import ClienteRepository

@hotelController.route('/tentar_login',methods = ['POST'])
def logar():
    try:
        session.permanent = True
        session['nome'] = verificar_entrada(request.form['Usuario']) 
        session['senha'] = criptografia(verificar_entrada(request.form['Senha']))
        if session['nome'] and session['senha']:
            lista_clientes = ClienteRepository.get_all_Cliente()
            for cliente in lista_clientes:
                if cliente.senha_hash == session['senha'] and cliente.nome ==session['nome']:
                    flash(f"Login realizado com sucesso {session['nome']}!","success")
                    return redirect(url_for("hotel.funcionando"))
        else:
            raise ValueError("A entrada não pode ser vazia.")
            
    except ValueError:
        registrar_erro(str(ValueError),"Algum dado foi passado sem valor válido.")
        flash(f"Login não foi realizado com sucesso {session['nome']}!","error")
        return render_template("login.html")

