from flask import redirect,url_for,render_template,request

from Controller.BlueprintController import hotelController


executou = False

@hotelController.route("/")
def index():
    global executou
    if not executou:
        #se quiser excluir os dados do banco para conseguir mexer direito
        executou=True
    return render_template("index.html")

@hotelController.route("/login")
def login():
    return render_template("login.html")

@hotelController.route("/cadastro")
def cadastro():
    return render_template("cadastro.html")

@hotelController.route("/funcionando")
def funcionando():
    return render_template("index2.html")

@hotelController.route("/logout")
def logout():
    return render_template("logout.html")