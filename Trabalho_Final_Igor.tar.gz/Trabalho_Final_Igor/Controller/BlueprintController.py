from flask import Blueprint

hotelController = Blueprint("hotel", __name__)