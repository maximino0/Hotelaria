from datetime import datetime

#criei esse arquivo para as nossas funções globais
registro_de_erros=[]
def registrar_erro(erro,descricao):
    if erro and descricao:
        registro=[datetime.now(),erro,descricao]
        registro_de_erros.append(registro)    #essa função cria um registro de erro com a data(data e hora), o valor do erro e a descrição desse erro.

def verificar_entrada(entrada):
    try:
        caracteres=["'", '"', ";", "--", "#", "/*", "*/", "=", "<", ">", "(", ")", "{", "}", "[", "]", "\\", "/", "%", "|", "&", "$", "`", "^", "~", "@", "?", "!", "+", "*", ":"]
        for char in entrada:
            if char in caracteres:
                raise ValueError(f'Caracter inválido encontrado: {char}')  
        return entrada
    except ValueError:
        registrar_erro(str(ValueError),"Erro na verificação de entrada, pois houve a tentativa de uma possivel injeção de código.")  #registra o erro
        return False

def criptografia(dados):
    pass